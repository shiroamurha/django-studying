from datetime import date
from curso import Curso



class Disciplina():

    def __init__(self, 
                curso: Curso
                carga_horaria: int, 
                nome: str, 
                ementa: str, 
                referencias: str, 
                data_fim: date, 
                data_inicio = date.today(), 
                sigla = 'N/A',
                ultima_discp = None
            ):

        self.curso = curso
        self.cod = ultima_discp.cod+1 if ultima_discp is not None else 0

        self.nome = nome
        self.ementa = ementa
        self.referencias = referencias
        self.carga_horaria = carga_horaria
        self.data_fim = data_fim
        self.data_inicio = data_inicio
        self.sigla = sigla

        self.ultima_discp = ultima_discp
        self.proxima_discp = None
        ultima_discp.proxima_discp = self



    def __str__(self):

        attrs = vars(self)
        to_string = ''

        for key in attrs.keys():
            to_string += f'{key.replace("_", ' ').title()}: {attrs[key]}'

        return to_string



    def listar_disciplinas_atuais(d: date):

        ultima_discp = self.ultima_discp
        discp_atuais = []

        # acha a primeira disciplina de todas
        while ultima_discp is not None:
            ultima_discp = ultima_discp.ultima_discp

        # passa por todas as disciplinas cadastradas e pega as que sao atuais
        primeira_discp = ultima_discp 
        while proxima_discp is not None:
            if proxima_discp.data_fim > date.today():
                discp_atuais.append(proxima_discp)
            
            # pega disciplina seguinte de 'proxima_discp'
            proxima_discp = proxima_discp.proxima_discp
        
        return set(discp_atuais)
                
        
        









