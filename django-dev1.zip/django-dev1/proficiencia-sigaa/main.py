from curso import Curso
from disciplina import Disciplina
from datetime import date



def main():
    curso_eixo = Curso(600, 'eixo', 'graduacao', 'eix')
    disciplina_eixo = Disciplina(curso_eixo, 20, 'eixo', 'a'*30, 'b'*50, date(1900,1,2), data_inicio = date(1900,1,1))

    ads = Curso(2300, 'Analise e Desenvolvimento de Sistemas', 'Graduacao', 'ADS', 'Melhor curso da tinga')
    prog1 = Disciplina(ads, 
        80, 
        'Programacao 1', 
        'Fundamentos e iniciacao em programacao', 
        'Alan Turing, Albert Einstein (todas as obras)',
        date(2025,12,31), 
        sigla = 'PRG01'
    )
    prog2 = Disciplina(ads, 
        110, 
        'Programacao 2', 
        'Orientacao a objeto e afins', 
        'Alan Turing, Albert Einstein (todas as obras)',
        date(2025,12,31), 
        sigla = 'PRG02'
    )
    optativa = Disciplina(ads, 
        60, 
        'Alguma optativa', 
        'Serve pra poder ter opçao', 
        'Alan Turing, Albert Einstein (todas as obras)',
        date(2024,12,31), 
        data_inicio = date(2024,7,1)
        sigla = 'OPT01'
    )


if __name__ == "__main__":
    main()